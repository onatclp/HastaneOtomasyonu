IF DB_ID('hastane') IS NOT NULL
     BEGIN
	       ALTER DATABASE [hastane] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
		   USE master 
		   Drop DATABASE hastane
	 END
   GO


CREATE DATABASE HASTANE
 
     ON PRIMARY (

	            NAME='hastanedb',
				FILENAME='c:\database\hastane_db.mdf',
				SIZE=5MB,
				MAXSIZE=100MB,
				FILEGROWTH=5MB
				)
	 LOG ON(
	           NAME='hastanedb_log',
			   FILENAME='c:\database\hastane_log.ldf',
			   SIZE=2MB,
			   MAXSIZE=50MB,
			   FILEGROWTH=1MB
           )
      GO

	  USE hastane

	  Create Table tblIL (
	  Kod CHAR(2)  Primary Key,
	  Il_ad� varchar(25) NOT NULL
           )
      GO
	  Create Table tblILCE (
	  Ilce_id int identity(1,1) Primary Key,
	  Ilce_ad� varchar(25) NOT NULL,
	  ILID CHAR(2) FOREIGN KEY REFERENCES tblIL(Kod)
	           ON DELETE CASCADE ON UPDATE CASCADE NOT NULL

            )
	  GO
	  Create Table tblMAHALLE(
	  Mahalle_id int identity(1,1) Primary Key,
	  Mahalle_adi varchar(30) NOT NULL,
	  ILID CHAR(2) FOREIGN KEY REFERENCES tblIL(Kod),
	  ILCEID int FOREIGN KEY REFERENCES tblILCE(Ilce_id),
	  )
	  GO
	  Create table tbl_CADDE_SOKAK (
	  Sokak_id int identity(1,1) Primary Key,
	  Sokak_ad� varchar(30) NOT NULL,
	  ILID CHAR(2) FOREIGN KEY REFERENCES tblIL(Kod),
	  ILCEID int FOREIGN KEY REFERENCES tblILCE(Ilce_id),
	  MAHALLEID int FOREIGN KEY REFERENCES tblMAHALLE(Mahalle_id),
      ) 
	  GO
	  Create table tbl_ADRES(
	  Adres_id int identity(1,1)Primary Key,
	  Dis_kapi_no varchar(3) NOT NULL, 
	  �c_kap�_no varchar(3), 
	  Adres_ac�klama varchar(100),
	  ILID CHAR(2) FOREIGN KEY REFERENCES tblIL(Kod),
	  ILCEID int FOREIGN KEY REFERENCES tblILCE(Ilce_id),
	  MAHALLEID int FOREIGN KEY REFERENCES tblMAHALLE(Mahalle_id),
	  CaddeSokakID int FOREIGN KEY REFERENCES tbl_CADDE_SOKAK(Sokak_id),
	  )
	  Go
	  Create table tbl_ALERJILER(
	  Alerji_id int identity(1,1)Primary Key,
	  Alerji_ad� varchar(50) NOT NULL,
	  )
	  GO
	  Create table tbl_HASTA(
	  TC_NO char(11) Primary Key,
	  Ad varchar(30) NOT NULL,
	  Soyad varchar(30) NOT NULL,
	  AdresID int FOREIGN KEY REFERENCES tbl_ADRES(Adres_id),
	  ILID CHAR(2) FOREIGN KEY REFERENCES tblIL(Kod),
	  ILCEID int FOREIGN KEY REFERENCES tblILCE(Ilce_id),
	  MAHALLEID int FOREIGN KEY REFERENCES tblMAHALLE(Mahalle_id),
	  CaddeSokakID int FOREIGN KEY REFERENCES tbl_CADDE_SOKAK(Sokak_id),
	  Cinsiyet SMALLINT, -- 0: Kad�n, 1: Erkek
	  DTarihi DATE NOT NULL,
	  Yas AS DATEDIFF(yy, DTarihi, GETDATE()),
	  Tel CHAR(10) CONSTRAINT chkTel CHECK (Tel LIKE '[0-9] [0-9] [0-9] [0-9] [0-9] [0-9] [0-9] [0-9] [0-9] [0-9]') NOT NULL,
	  
	  E_posta varchar(50) CONSTRAINT unqHastaMail UNIQUE
	                      CONSTRAINT chkHastaMail CHECK (E_posta LIKE '%@%.%')
						  CONSTRAINT notnullHastaMail NOT NULL,
     Boy varchar(3), --cm cinsinden
	 Kilo varchar(3),--kg cinsinden
	 Kan_Grubu varchar(3),--AB+,B- G�B�
	 Sifre varchar(20) CONSTRAINT chkHastaSifre CHECK (
        LEN(Sifre) >= 8 AND 
        LEN(Sifre) <= 16 AND
        Sifre LIKE '%[A-Z]%' AND
        Sifre LIKE '%[a-z]%' AND
        Sifre LIKE '%[0-9]%' AND
        Sifre LIKE '%[!@#$%^&*()\-_=+\[\]{}|;:,.<>?/`%'
    ) NOT NULL,
	 Hesap_Onay_D SMALLINT  -- 0: ONAYLANMAMI�, 1: ONAYLANMI�
	 )
	 GO 
	
	 CREATE table tblHastaAlerji (--Hastan�n sahip oldu�u alerjiler
	 ID int  identity(1,1) PRIMARY KEY,
	 HastaID char(11) FOREIGN KEY REFERENCES tbl_HASTA(TC_NO),
	 Alerji_Ad� varchar(50),
	 AlerjiID int FOREIGN KEY REFERENCES tbl_ALERJILER(Alerji_id)
	  )
	  GO
	  
	  
	  
	  CREATE table tblHastaneTuru (
	  ID int Identity(1,1) PRIMARY KEY,
	  Tur_Adi varchar(50) NOT NULL
	  )
	  GO

	  CREATE table tblHastane(
	  ID int Identity(1,1) PRIMARY KEY,
	  Hastane_Adi varchar(50) NOT NULL,
	  Tel CHAR(10) CONSTRAINT chkTel2 CHECK (Tel LIKE '[0-9] [0-9] [0-9] [0-9] [0-9] [0-9] [0-9] [0-9] [0-9] [0-9]') NOT NULL,
	  AdresID int FOREIGN KEY REFERENCES tbl_ADRES(Adres_id),
	  ILKoduID CHAR(2) FOREIGN KEY REFERENCES tblIL(Kod),
	  ILCEKoduID int FOREIGN KEY REFERENCES tblILCE(Ilce_id),
	  MAHALLEKoduID int FOREIGN KEY REFERENCES tblMAHALLE(Mahalle_id),
	  CaddeSokakKoduID int FOREIGN KEY REFERENCES tbl_CADDE_SOKAK(Sokak_id),
	  TurID int FOREIGN KEY REFERENCES tblHastaneTuru(ID)
	  )
	  GO 

	  CREATE table tblBolumTuru(
	  ID int identity(1,1) PRIMARY KEY,
	  Bolum_Adi varchar(30) NOT NULL,
	  )
	  GO

	  CREATE table tblPoliklinik(
	  ID int identity(1,1) PRIMARY KEY,
	  Poliklinik_TurID int FOREIGN KEY REFERENCES tblBolumTuru(ID) 
	  )
	  GO

	  CREATE table tblHastane_Pol( --Hastanede bulunan poller
	  ID int identity(1,1) PRIMARY KEY,
	  OdaNO varchar(3) NOT NULL,
	  KatNO varchar(2) NOT NULL,
	  Pol_Adi varchar(30) NOT NULL,
	  HastaneID int FOREIGN KEY REFERENCES tblHastane(ID),
	  PolID int FOREIGN KEY REFERENCES tblPoliklinik(ID)
	  )
	  GO

	  CREATE table tblUnvan(
	  ID int identity(1,1) PRIMARY KEY,
	  Unvan_Adi varchar(20) NOT NULL
	  ) 
	  GO

	  CREATE table tblBrans(
	  ID int identity(1,1) PRIMARY KEY,
	  Brans_Adi varchar(20) NOT NULL,
	  )
	  Go



	  CREATE table tblCalismaTakvimi(
	  ID int identity(1,1) PRIMARY KEY,
	  Baslangic_Saati TIME NOT NULL,
	  Bitis_Saati TIME NOT NULL,
	  Tarih DATE NOT NULL
	  )
	  GO

	  CREATE table tblPersonel(
	  ID int identity(1,1) PRIMARY KEY,
	  TC_NO char(11) UNIQUE NOT NULL,
	  Ad varchar(20) NOT NULL ,
	  Soyad varchar(30) NOT NULL,
	  Cinsiyet SMALLINT NOT NULL,--0=kad�n 1=erkek
	  DTarihi DATE NOT NULL,
	  Yas AS DATEDIFF(yy, DTarihi, GETDATE()),
	  Sifre varchar(20) CONSTRAINT chkPersonelSifre CHECK (
        LEN(Sifre) >= 8 AND 
        LEN(Sifre) <= 16 AND
        Sifre LIKE '%[A-Z]%' AND
        Sifre LIKE '%[a-z]%' AND
        Sifre LIKE '%[0-9]%' AND
        Sifre LIKE '%[!@#$%^&*()\-_=+\[\]{}|;:,.<>?/`%'
    ) NOT NULL,
	  Tel CHAR(10) CONSTRAINT chkTel3 CHECK (Tel LIKE '[0-9] [0-9] [0-9] [0-9] [0-9] [0-9] [0-9] [0-9] [0-9] [0-9]') NOT NULL,
	  
	  E_posta varchar(50) CONSTRAINT unqHastaMail2 UNIQUE
	                      CONSTRAINT chkHastaMail2 CHECK (E_posta LIKE '%@%.%')
						  CONSTRAINT notnullHastaMail NOT NULL,
	  BolumuID int FOREIGN KEY REFERENCES tblBolumTuru(ID),
	  AdresiID int FOREIGN KEY REFERENCES tbl_ADRES(Adres_id),
	  HastanesiID int FOREIGN KEY REFERENCES tblHastane(ID),
	  Calisma_TakvimiID int FOREIGN KEY REFERENCES tblCalismaTakvimi(ID),
	  UnvanID int FOREIGN KEY REFERENCES tblUnvan(ID),
	  BransID int FOREIGN KEY REFERENCES tblBrans(ID)

	  )
	 Go
	
     
	 

	  CREATE table tblHastanePersoneli(
	  ID int identity(1,1) PRIMARY KEY,
	  IseBaslamaTarih DATE NOT NULL,
	  IstenAyr�lmaTarih DATE,
	  PersonelID int FOREIGN KEY REFERENCES tblPersonel(ID),
	  Calistigi_HastaneID int FOREIGN KEY REFERENCES tblHastane(ID)
	  )
	  GO
	  

	  CREATE table tblRandevuTuru(
	  ID int identity(1,1) PRIMARY KEY,
	  Tur_Adi varchar(20) NOT NULL
	  )
	  GO

	  CREATE table tblTetkikTuru(
	  ID int identity(1,1) PRIMARY KEY,
	  Tetkik_Turu_Adi varchar(20) NOT NULL 
	  )
	  GO

	  CREATE table tblTetkik(
	  ID int identity(1,1) PRIMARY KEY,
	  Tetkik_Adi varchar(20) NOT NULL,
	  Alt_Deger float NOT NULL,
	  Ust_Deger float NOT NULL,
	  TurID int FOREIGN KEY REFERENCES tblTetkikTuru(ID)
	  )
	  GO
	  
	  CREATE table tblRandevu(
	  ID int identity(1,1) PRIMARY KEY,
	  Randevu_Tarihi DATE NOT NULL,
	  Randevu_Saati TIME NOT NULL,
	  TuruID int FOREIGN KEY REFERENCES tblRandevuTuru(ID),
	  Calisma_TakvimiID int FOREIGN KEY REFERENCES tblCalismaTakvimi(ID),
	  HastaID char(11) FOREIGN KEY REFERENCES tbl_HASTA(TC_NO),
	  DoktorID int FOREIGN KEY REFERENCES tblPersonel(ID)
	  )
	  GO

	  CREATE table tblRandevudaIstenenTetkik(
	  ID int identity(1,1) PRIMARY KEY,
	  Istenen_Tetkik varchar(50),
      RandevuID int FOREIGN KEY REFERENCES tblRandevu(ID),
	  TetkikID int FOREIGN KEY REFERENCES tblTetkik(ID)
	  )
	  GO

	  CREATE table tblRandevuAl�nabilecekTarihler(
	  ID int identity(1,1) PRIMARY KEY,
	  Alinabilecek_Tarih DATETIME NOT NULL,
      RandevuID int FOREIGN KEY REFERENCES tblRandevu(ID),
	  TakvimID int FOREIGN KEY REFERENCES tblCalismaTakvimi(ID)
	  )
	  Go

	  CREATE table tblSonuc ( --Randevu ve Tetkik aras�ndaki ba�dan ��kan tablo
	  ID int identity(1,1) PRIMARY KEY,
	  Sonuc varchar(100) NOT NULL,
	  RandevuID int FOREIGN KEY REFERENCES tblRandevu(ID),
	  TetkikTuruID int FOREIGN KEY REFERENCES tblTetkikTuru(ID)
	  )
	  Go

	  CREATE table tblEtkenMadde(
	  ID int identity(1,1) PRIMARY KEY,
	  Madde_Adi varchar(20) NOT NULL
	  )
	  GO

	  CREATE table tblUreticiFirma(
	  ID int identity(1,1) PRIMARY KEY,
	  Firma_Adi varchar(20) NOT NULL
	  )
	  GO

	  CREATE table tblYasGrubu(
	  ID int identity(1,1) PRIMARY KEY,
	  Grup_Adi varchar(30) NOT NULL,
	  Periyod varchar(20) NOT NULL,
	  Doz varchar(20) NOT NULL
	  )
	  GO

	  CREATE table tblIlac(
	  ID int identity(1,1) PRIMARY KEY,
	  Barkod int NOT NULL,
	  Ilac_Adi varchar(30) NOT NULL ,
	  Ac�klamas� varchar(100) NOT NULL,
	  Yas_GrubuID int FOREIGN KEY REFERENCES tblYasGrubu(ID),
	  Uretici_F�rmaID int FOREIGN KEY REFERENCES tblUreticiFirma(ID)
	  )
	  GO

	  CREATE table tblIlacinEtkenMaddesi(
	  ID int identity(1,1) PRIMARY KEY,
	  Ilactaki_Etken_Madde varchar(100),
	  IlacID int FOREIGN KEY REFERENCES tblIlac(ID),
	  EtkenMaddeID int FOREIGN KEY REFERENCES tblEtkenMadde(ID)	 
	  )
	  GO

	  CREATE table tblBolumTuruIlac(
	  ID int identity(1,1) PRIMARY KEY,
	  Ilac_Adi varchar(30) NOT NULL,
	  Doktor_BransID int FOREIGN KEY REFERENCES tblBolumTuru(ID),
	  IlacID int FOREIGN KEY REFERENCES tblIlac(ID)
	  )
	  GO
	  
	  CREATE table tblTeshis(
	  ID int identity(1,1) PRIMARY KEY,
	  Teshis_Adi varchar(30) NOT NULL	
	  )
	  GO

	  CREATE table tblRandevudaVerilenTeshis(
	  ID int identity(1,1) PRIMARY KEY,
	  Doktorun_Koydugu_Teshis varchar(100) NOT NULL,
	  RandevuID int FOREIGN KEY REFERENCES tblRandevu(ID),
	  TeshisID int FOREIGN KEY REFERENCES tblTeshis(ID),
	  PersonelID int FOREIGN KEY REFERENCES tblPersonel(ID),
	
	  )
	  GO

	  CREATE table tblTeshisIlac(
	  ID int identity(1,1) PRIMARY KEY,
	  TeshisID int FOREIGN KEY REFERENCES tblTeshis(ID),
	  IlacID int FOREIGN KEY REFERENCES tblIlac(ID),
	  Teshise_Gore_Ilac varchar(50) 
	  )
	  GO

	  CREATE table tblRecete(
	  ID int identity(1,1) PRIMARY KEY,
	  Recete_Kodu varchar(30) NOT NULL,
	  Yaz�ld�g�_Tarih DATETIME NOT NULL,
	  Son_Gecerlilik_Tarih DATETIME NOT NULL,
	  Al�nd�g�_Tarih DATETIME,
	  RandevuID int FOREIGN KEY REFERENCES tblRandevu(ID),
	  DoktorID int FOREIGN KEY REFERENCES tblPersonel(ID)
	  )
	  GO

	  CREATE table tblReceteIlac(
	  ID int identity(1,1) PRIMARY KEY,
	  Doz varchar(20) NOT NULL,
	  Kullanim_Sikligi varchar(20) NOT NULL,
	  Kullanim_Periyotu varchar(20) NOT NULL,
	  ReceteID int FOREIGN KEY REFERENCES tblRecete(ID),
	  IlacID int FOREIGN KEY REFERENCES tblIlac(ID)
	  )
	  GO
	 