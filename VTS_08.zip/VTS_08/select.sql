SELECT --select 2
    H.ILID AS '�l Kodu',
    SUM(CASE WHEN H.Cinsiyet = 1 THEN 1 ELSE 0 END) AS 'Toplam Erkek',
    SUM(CASE WHEN H.Cinsiyet = 0 THEN 1 ELSE 0 END) AS 'Toplam Kad�n',
    COUNT(*) AS 'Genel Toplam',
    AVG(H.Yas) AS 'Ortalama Ya�'
	FROM tbl_HASTA H
	INNER JOIN tblRandevu R ON H.TC_NO = R.HastaID
	INNER JOIN tblRandevudaVerilenTeshis RTVT ON R.ID = RTVT.RandevuID
	INNER JOIN tblTeshis T ON RTVT.TeshisID = T.ID
	WHERE
    T.Teshis_Adi = 'Farenjit'
    AND H.TC_NO NOT IN (
        SELECT H.TC_NO
        FROM tbl_HASTA H
        WHERE
            H.TC_NO  IN (SELECT HastaID 
							FROM   tblRandevu  
							WHERE    ID IN 
								(SELECT  RandevuID 
								FROM tblRandevudaVerilenTeshis 
								WHERE TeshisID IN 
									(SELECT ID 
									FROM tblTeshis 
									WHERE Teshis_Adi = 'Bron�it' ))))
	GROUP BY
		H.ILID
	HAVING
		COUNT(*) >= 100;
	


SELECT --select 1
    T.Teshis_Adi AS 'Te�his �smi',
    ISNULL(COUNT(R.ID), 0) AS 'Randevu Say�s�',
    ISNULL(COUNT(DISTINCT R.HastaID), 0) AS 'Farkl� Hasta Say�s�',
    ISNULL(SUM(CASE WHEN S.TetkikTuruID = 1 AND S.Sonuc > 5 THEN 1 ELSE 0 END), 0) AS 'Ka� Randevuda CPR Kan Tahlili De�eri'
	FROM 
		tblTeshis T
			LEFT JOIN tblRandevu R ON T.ID = R.TuruID 
			LEFT JOIN tblRandevudaVerilenTeshis RVT ON R.ID = RVT.RandevuID
			LEFT JOIN tblRandevudaIstenenTetkik ITK ON R.ID = ITK.RandevuID
			LEFT JOIN tblTetkik TK ON ITK.TetkikID = TK.ID
			LEFT JOIN tblTetkikTuru TT ON TK.TurID = TT.ID
			LEFT JOIN tblSonuc S ON R.ID = S.RandevuID
			LEFT JOIN tblPersonel P ON RVT.PersonelID = P.ID
			LEFT JOIN tblHastanePersoneli HP ON HP.PersonelID = P.ID
			LEFT JOIN tblHastane H ON HP.Calistigi_HastaneID = H.ID
			LEFT JOIN tblHastaneTuru HT ON H.TurID = HT.ID
	WHERE 
		H.Hastane_Adi = 'Yalova Devlet Hastanesi' 
		AND HT.Tur_Adi = 'Devlet' 
		AND TT.Tetkik_Turu_Adi = 'CPR Kan Tahlili'
		AND R.Randevu_Tarihi >= DATEADD(month, -1, GETDATE()) 
		AND R.Randevu_Tarihi < GETDATE()
	GROUP BY 
		T.Teshis_Adi;

